const content = fragmentElement.querySelector('.auto-deployed-fragment');
